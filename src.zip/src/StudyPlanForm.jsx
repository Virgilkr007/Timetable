import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { generateSchedule } from './Scheduler'; // I  used the same logic  from filescheduler.js

const StudyPlanForm = () => {
  const navigate = useNavigate();
  const [hoursPerDay, setHoursPerDay] = useState(4);
  const [duration, setDuration] = useState('');
  const [courses, setCourses] = useState([{ name: '', units: '', importance: '' }]);

  const handleAddCourse = () => {
    setCourses([...courses, { name: '', units: '', importance: '' }]);
  };

  const handleCourseChange = (index, field, value) => {
    const updatedCourses = courses.map((course, i) =>
      i === index ? { ...course, [field]: value } : course
    );
    setCourses(updatedCourses);
  };

  const handleGenerate = () => {
    if (!duration) {
      alert('Please select a duration.');
      return;
    }

    const validatedCourses = courses.filter(course => course.name && !isNaN(Number(course.units)) && Number(course.units) > 0 && course.importance);
    if (validatedCourses.length !== courses.length) {
      alert('Please complete all course fields with valid data.');
      return;
    }

    const config = {
      hoursPerDay,
      duration: Number(duration),
      courses: validatedCourses.map(course => ({ ...course, units: Number(course.units) })),
    };

    const result = generateSchedule(config);
    localStorage.setItem('timetable', JSON.stringify(result));
    localStorage.setItem('scheduleData', JSON.stringify(config));

    // Clear form (reactive reset)
    setHoursPerDay(4);
    setDuration('');
    setCourses([{ name: '', units: '', importance: '' }]);

    navigate('/generated');
  };

  return (
    <section>
      <h1 className="retro">
        Hi Friend 
        <svg className="icon1" width="120" height="120" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
          <circle cx="60" cy="60" r="50" fill="#FFD93D"/>
          <circle cx="42" cy="50" r="5" fill="#333"/>
          <circle cx="78" cy="50" r="5" fill="#333"/>
          <path d="M40 70 Q60 85 80 70" stroke="#333" strokeWidth="5" fill="none" strokeLinecap="round"/>
        </svg>
      </h1>
      <p>Struggling with your reading plan?<br/>We've got you covered.
        <svg className="icon2" width="120" height="120" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
          <path d="M30 65 L50 85 L90 40" fill="none" stroke="#2ECC71" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="100" strokeDashoffset="100">
            <animate attributeName="stroke-dashoffset" from="100" to="0" dur="1.5s" repeatCount="indefinite"/>
          </path>
        </svg>
      </p>
      <label>Cycle in hours</label>
      <input type="range" min="1" max="12" value={hoursPerDay} onChange={(e) => setHoursPerDay(e.target.value)} />
      <input type="number" min="1" max="12" value={hoursPerDay} onChange={(e) => setHoursPerDay(e.target.value)} />

      <label htmlFor="period">Duration:</label>
      <select id="period" value={duration} onChange={(e) => setDuration(e.target.value)}>
        <option value="">--Choose duration--</option>
        <option value="1">1 week</option>
        <option value="2">2 weeks</option>
        <option value="3">1 month</option>
        <option value="4">2 months</option>
        <option value="5">3 months</option>
        <option value="6">6 months</option>
        <option value="7">1 year</option>
      </select>

      <table id="tablebody">
        <thead>
          <tr>
            <th>Course</th>
            <th>Units</th>
            <th>Importance</th>
          </tr>
        </thead>
        <tbody>
          {courses.map((course, index) => (
            <tr key={index}>
              <td><input value={course.name} onChange={(e) => handleCourseChange(index, 'name', e.target.value)} /></td>
              <td><input type="number" value={course.units} onChange={(e) => handleCourseChange(index, 'units', e.target.value)} /></td>
              <td>
                <select value={course.importance} onChange={(e) => handleCourseChange(index, 'importance', e.target.value)}>
                  <option value="">--Select--</option>
                  <option value="important">Important</option>
                  <option value="regular">Regular</option>
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button id="new-row" onClick={handleAddCourse}>Add Course</button>

      <div className="planbtn">
        <button id="create-plan" onClick={handleGenerate}>Generate Reading plan</button>
      </div>
    </section>
  );
};

export default StudyPlanForm;