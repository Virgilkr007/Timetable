import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Preview = () => {
  const navigate = useNavigate();
  const [meta, setMeta] = useState(null);
  const [timetable, setTimetable] = useState(null);
  const [courses, setCourses] = useState([]);
  const [summaries, setSummaries] = useState([]);

  useEffect(() => {
    const raw = localStorage.getItem('timetable');
    if (!raw) {
      alert('No generated timetable found. Redirecting...');
      navigate('/');
      return;
    }

    const { meta: loadedMeta, timetable: loadedTimetable } = JSON.parse(raw);
    setMeta(loadedMeta);
    setTimetable(loadedTimetable);

    // Extract unique courses
    const allCourses = new Set();
    Object.keys(loadedTimetable).forEach(day => {
      loadedTimetable[day].forEach(slot => {
        if (slot) allCourses.add(slot);
      });
    });
    const sortedCourses = Array.from(allCourses).sort();
    setCourses(sortedCourses);

    // Compute summaries
    const newSummaries = sortedCourses.map(course => {
      let totalSlots = 0;
      Object.keys(loadedTimetable).forEach(day => {
        totalSlots += loadedTimetable[day].filter(slot => slot === course).length;
      });
      return `${course}: ${totalSlots} total hour${totalSlots !== 1 ? 's' : ''}`;
    });
    setSummaries(newSummaries);
  }, [navigate]);

  if (!timetable || !meta) return null;

  const days = Object.keys(timetable);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="page">
      <h1>Personalised Study Timetable</h1>
      <div className="meta">{`Study plan: ${meta.hoursPerDay} hours/day • ${meta.totalDays} days`}</div>

      <div className="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Course</th>
              {days.map(day => <th key={day}>{day}</th>)}
            </tr>
          </thead>
          <tbody>
            {courses.map(course => (
              <tr key={course}>
                <td className="course">{course}</td>
                {days.map(day => {
                  const count = timetable[day].filter(slot => slot === course).length;
                  return <td key={day}>{count > 0 ? count : ''}</td>;
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="summary">
        {summaries.map((summary, index) => <div key={index}>{summary}</div>)}
      </div>

      <div className="controls">
        <button className="back" onClick={() => navigate(-1)}>Back</button>
        <button className="download" onClick={handlePrint}>Download PDF</button>
      </div>
    </div>
  );
};

export default Preview;