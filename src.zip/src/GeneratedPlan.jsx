import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const GeneratedPlan = () => {
  const navigate = useNavigate();
  const [timetable, setTimetable] = useState(null);
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    const raw = localStorage.getItem('timetable');
    if (!raw) {
      alert('No schedule data found. Redirecting...');
      navigate('/');
      return;
    }

    const { timetable: loadedTimetable } = JSON.parse(raw);
    setTimetable(loadedTimetable);

    const allCourses = new Set();
    Object.keys(loadedTimetable).forEach(day => {
      loadedTimetable[day].forEach(slot => {
        if (slot) allCourses.add(slot);
      });
    });
    setCourses(Array.from(allCourses).sort());
  }, [navigate]);

  if (!timetable) return null;

  const days = Object.keys(timetable);

  return (
    <body className="generated-body"> {/* Use a class for styling */}
      <div className="prevbtn"><button className="preview-btn" onClick={() => navigate('/preview')}>Preview / Download</button>
      </div>
      <h2>
        <a onClick={() => navigate('/')} style={{ cursor: 'pointer' }}>
          <svg className="arrowhead" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="10 18 4 12 10 6" />
            <line x1="4" y1="12" x2="20" y2="12" />
          </svg> Go back
        </a>
      </h2>
      <h1>Your Personalised Reading Plan.<br/> Read Responsively
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="1em" height="1em" aria-hidden="true">
          <circle cx="32" cy="32" r="30" fill="#FFD93B"/>
          <ellipse cx="22" cy="26" rx="4" ry="6" fill="#3E4347"/>
          <path d="M38 24c3 0 6 2 6 4s-3 4-6 4" fill="none" stroke="#3E4347" strokeWidth="3" strokeLinecap="round"/>
          <path d="M20 40c6 4 18 4 24-2" fill="none" stroke="#3E4347" strokeWidth="3" strokeLinecap="round"/>
        </svg>
      </h1>
      <div className="table-wrapper">
        <table className="planner-table">
          <thead>
            <tr>
              <th>Course</th>
              {days.map(day => <th key={day}>{day}</th>)}
            </tr>
          </thead>
          <tbody>
            {courses.map(course => (
              <tr key={course}>
                <td>{course}</td>
                {days.map(day => {
                  const count = timetable[day].filter(slot => slot === course).length;
                  return <td key={day}>{count > 0 ? count : ''}</td>;
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="regen"><button className="renew" onClick={() => { localStorage.removeItem('timetable'); localStorage.removeItem('scheduleData'); navigate('/'); }}>
        Regenerate
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M16.5 6.5A7 7 0 0 0 5.6 9"/>
          <polyline points="5 4 5 9 10 9"/>
          <path d="M7.5 17.5A7 7 0 0 0 18.4 15"/>
          <polyline points="19 20 19 15 14 15"/>
        </svg>
      </button></div>
    </body>
  );
};

export default GeneratedPlan;