export function generateSchedule(config) {
  const { hoursPerDay, duration, courses } = config;

  const totalDays = getTotalDays(duration);
  const timetable = {};

  // 1. Assign STATUS + WEIGHT
  const courseMeta = courses.map(course => {
    const status = getStatus(course.units, course.importance);
    const weight = getWeight(status);

    return {
      name: course.name,
      weight,
      remaining: weight
    };
  });

  // 2. Initiate empty timetable
  for (let d = 1; d <= totalDays; d++) {
    timetable[`Day ${d}`] = Array(hoursPerDay).fill(null);//check this line out  later

  }

  // 3. RELATIVE DISTRIBUTION of slots
  const days = Object.keys(timetable);

  days.forEach(day => {
    let slotsFilled = 0;

    // Sort daily by remaining weight (DESC)
    const dailyCourses = [...courseMeta].sort(
      (a, b) => b.remaining - a.remaining
    );

    for (let i = 0; i < dailyCourses.length; i++) {
      if (slotsFilled >= hoursPerDay) break;

      const course = dailyCourses[i];

      if (course.remaining <= 0) continue;
      if (slotsFilled % 2 === 1) continue; 

      timetable[day][slotsFilled] = course.name;
      course.remaining--;
      slotsFilled++;
    }
  });

  const meta = {
    hoursPerDay,
    totalDays
  };

  return { timetable, meta };
}

function getStatus(units, importance) {
  if (units <= 2 && importance === 'regular') return 'A';
  if (
    (units <= 2 && importance === 'important') ||
    (units >= 3 && importance === 'regular')
  ) return 'B';
  return 'C';
}

function getWeight(status) {
  if (status === 'A') return 10;
  if (status === 'B') return 15;
  return 25;
}

function getTotalDays(duration) {
  switch (duration) {
    case 1: return 7;
    case 2: return 14;
    case 3: return 30;
    case 4: return 60;
    case 5: return 90;
    case 6: return 180;
    case 7: return 365;
    default: return 7;
  }
}