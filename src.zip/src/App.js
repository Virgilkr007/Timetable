import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import StudyPlanForm from './StudyPlanForm';
import GeneratedPlan from './GeneratedPlan';
import Preview from './Preview';
import './style.css'; 
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<StudyPlanForm />} />
        <Route path="/generated" element={<GeneratedPlan />} />
        <Route path="/preview" element={<Preview />} />
      </Routes>
    </Router>
  );
}

export default App;